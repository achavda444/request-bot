import requests
from bs4 import BeautifulSoup

url = "https://ooredoo.girogamez.com/subscribe"  # Replace with the actual URL
response = requests.get(url)

# Check if the request was successful
if response.status_code == 200:
    soup = BeautifulSoup(response.text, "html.parser")
    input_fields = soup.find_all("input")  # Find all input fields
    print(input_fields)
    if input_fields:
        # Get the first input field
        first_input = input_fields[1]
        
        # Construct the form data with the input field's name or ID
        data = {
            first_input["name"]: "79988778",  # Replace with the value you want to input
            # Add other form data if needed
        }

        # Find the form's action URL
        form = first_input.find_parent("form")
        action_url = form.get("action")

        # Send a POST request to the form's action URL with the data
        response = requests.post(action_url, data=data)

        # Check if the request was successful
        if response.status_code == 200:
            print("Value submitted successfully")
        else:
            print("Failed to submit the value")
    else:
        print("No input fields found on the page")
else:
    print("Failed to retrieve the webpage")
