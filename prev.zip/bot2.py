from selenium import webdriver

url = "https://ooredoo.girogamez.com/subscribe"  # Replace with the actual URL

# Create a new instance of the Chrome browser
driver = webdriver.Chrome()

# Navigate to the URL
driver.get(url)

# Find and interact with the input element
input_element = driver.find_element_by_css_selector("input")  # Use the appropriate CSS selector
input_element.send_keys("your_value_here")

# Submit the form (if needed)
# form = input_element.find_element_by_xpath("./ancestor::form")
# form.submit()

# Close the browser
driver.quit()


# from selenium import webdriver

# url = "https://ooredoo.girogamez.com/subscribe"
# driver = webdriver.Chrome(executable_path="C:\Users\ARYAN CHAVDA\OneDrive\Desktop\chromedriver")  # You need to have Chrome driver installed

# driver.get(url)

# # Wait for the page to load completely and the dynamic content to be rendered
# # You might need to adjust the waiting time based on the page's behavior
# # driver.implicitly_wait(10)

# # # Now you can find the specific elements using various methods
# # # For example, let's find all input elements
# # input_elements = driver.find_elements_by_tag_name("input")

# # for input_element in input_elements:
# #     print(input_element.get_attribute("name"))

# # driver.quit()
