const torrequest = require('tor-request');

const apiUrl = 'http://localhost:8080/login';
const requestData = {
  email: 'aryan@girofintech.com',
  password: 'Admin@12345'
};
const requestLimit = 10; // Limit the number of requests

async function makePostRequests() {
  for (let requestsMade = 0; requestsMade < requestLimit; requestsMade++) {
    torrequest.request({
      uri: apiUrl,
      method: 'POST',
      json: requestData
    }, (error, response, body) => {
      if (error) {
        console.error('Request error:', error);
      } else {
        console.log(`Response from Tor:`, body);
      }
    });
  }
}

makePostRequests();
