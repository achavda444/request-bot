# import requests
# from bs4 import BeautifulSoup

# url = "https://ooredoo.girogamez.com/subscribe"  # Replace with the actual URL
# response = requests.get(url)

# print(response)

# # Check if the request was successful
# if response.status_code == 200:
#     soup = BeautifulSoup(response.text)
#     print(soup)


from requests_html import HTMLSession
from bs4 import BeautifulSoup

session = HTMLSession()
url = "https://ooredoo.girogamez.com/subscribe"
response = session.get(url)
response.html.render()

# Use BeautifulSoup to parse the dynamically loaded content
soup = BeautifulSoup(response.html.html, "html.parser")

# Find the second input element by its placeholder text
second_input = soup.find("input", {"placeholder": "Enter Your 8 Digit Mobile Number"})

# Find the button by its text and class
subscribe_button = soup.find("button",{"type":"button"})
print(second_input)
print(subscribe_button)

# Now you can interact with these elements as needed
if second_input and subscribe_button:
    # Fill in the input field if needed
    second_input["value"] = "1234456789"
    # print(second_input)
    # Click the submit button
    subscribe_button.click()
    print(subscribe_button)
session.close()


