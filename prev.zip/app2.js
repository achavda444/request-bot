const axios = require('axios');

const apiUrl = 'https://api.ktgamez.com/ooredoo/send-otp';
let mobile = "11223344"
const requestData = {
  mobile:mobile
};
const requestLimit = 1; // Limit the number of requests

async function makePostRequests() {
  for (let requestsMade = 0; requestsMade < requestLimit; requestsMade++) {
    try {
      const response = await axios.post(apiUrl, requestData);
      console.log(`Response:`, response.data);
      if(response.data.statusCode==="200"){
        console.log("hi")
        let validateObject = {
            mobile:mobile,
            otp:'1234',
            transId:response.data.body.transId
        }
        const response2 = await axios.post('https://api.ktgamez.com/ooredoo/validate-otp', validateObject);
      }
    } catch (error) {
      console.error('Request error:', error.response.data);
    }
  }
}

makePostRequests();
